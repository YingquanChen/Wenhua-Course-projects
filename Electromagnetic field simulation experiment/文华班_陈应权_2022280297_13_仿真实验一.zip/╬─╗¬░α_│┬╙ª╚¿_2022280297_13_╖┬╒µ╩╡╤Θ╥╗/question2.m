warning('off', 'all');
% Initialize parameters
R = 0.01; % Radius of the disk, in meters
adj = 1.3;
Q = 1 + adj; % Charge on the disk, in Coulombs
epsilon_0 = 8.854e-12; % Vacuum permittivity

sigma = Q / (pi * R^2); % Charge surface density

% Points on the z-axis
z_values = linspace(0, 0.03, 100); % Generate 100 z-values from 0 to 0.03 meters

Ez_values = zeros(size(z_values)); % Initialize array for electric field strength

% Calculate electric field strength at each z position
for i = 1:length(z_values)
    z = z_values(i);
    integrand = @(s) s ./ (z^2 + s.^2).^(3/2);
    integral_result = integral(integrand, 0, R, 'ArrayValued', true); % Add 'ArrayValued' option
    Ez_values(i) = sigma * z / (2 * epsilon_0) * integral_result;
end

% Load data from file
a = importdata("E:\CST_result\1.2data.txt");
data = a.data;

% Plot both calculated and imported electric field data
plot(z_values*1000, Ez_values, 'LineWidth', 2, 'DisplayName', 'calculated');
hold on;
plot(data(:, 1), data(:, 2), '--', 'LineWidth', 2, 'Marker', 'o', 'MarkerSize', 3,'DisplayName', 'imported');
hold off;

% Set labels and title
xlabel('Z (mm)');
ylabel('Electric Field E_z (N/C)');
title('Comparison of Electric Field above a Charged Disk');
legend('show');
grid on;
