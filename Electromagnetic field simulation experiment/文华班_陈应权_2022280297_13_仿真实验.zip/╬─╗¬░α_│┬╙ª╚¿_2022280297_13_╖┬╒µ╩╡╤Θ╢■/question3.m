% Constants
mu0 = 4 * pi * 1e-7; % Permeability of free space (H/m)
adj = 13/10; % Given adj value
mu_r = 4 + adj; % Relative permeability
I = 1; % Current (A)

% Radii
a = 0.5e-3; % Inner radius (m)
b = 1e-3; % Middle radius (m)
c = 1.5e-3; % Outer radius (m)

% Define x positions where H and B are to be calculated
x_positions = linspace(-40e-3, 40e-3, 100); % Example x positions from -40mm to 40mm

% Initialize H and B arrays
H = zeros(size(x_positions));
B = zeros(size(x_positions));

% Calculate H and B at each x position
for i = 1:length(x_positions)
    x = x_positions(i);
    if abs(x) < a
        % Region 1: r < a
        H(i) = I * abs(x) / (2 * pi * a^2);
        B(i) = mu0 * H(i);
    elseif abs(x) >= a && abs(x) < b
        % Region 2: a <= r < b
        H(i) = I / (2 * pi * abs(x));
        B(i) = mu0 * mu_r * H(i);
    elseif abs(x) >= b && abs(x) < c
        % Region 3: b <= r < c
        H(i) = (I / (2 * pi * abs(x))) - (I * (abs(x) - b) / (2 * pi * c^2));
        B(i) = mu0 * H(i);
    else
        % Region 4: r >= c
        H(i) = 0;
        B(i) = 0;
    end
end

% Load CST data for H
data_H = readmatrix("E:\CST_result\2.3dataH.txt", 'FileType', 'text', 'NumHeaderLines', 2);
x_cst_H = data_H(:, 1) * 1e-3; % Convert mm to m
H_cst = data_H(:, 2);

% Load CST data for B
data_B = readmatrix("E:\CST_result\2.3dataB.txt", 'FileType', 'text', 'NumHeaderLines', 2);
x_cst_B = data_B(:, 1) * 1e-3; % Convert mm to m
B_cst = data_B(:, 2);

% Plot H vs x
figure;
plot(x_positions * 1e3, H, 'bo-', 'DisplayName', 'Calculated H'); % Convert x_positions to mm for plotting, using circle markers
hold on;
plot(x_cst_H * 1e3, H_cst, 'r^-', 'DisplayName', 'CST H'); % Convert x_cst_H to mm for plotting, using triangle markers
xlabel('x (mm)');
ylabel('Magnetic field H (A/m)');
title('Magnetic field H along the x-axis');
legend;
grid on;

% Plot B vs x
figure;
plot(x_positions * 1e3, B, 'bo-', 'DisplayName', 'Calculated B'); % Convert x_positions to mm for plotting, using circle markers
hold on;
plot(x_cst_B * 1e3, B_cst, 'r^-', 'DisplayName', 'CST B'); % Convert x_cst_B to mm for plotting, using triangle markers
xlabel('x (mm)');
ylabel('Magnetic flux density B (T)');
title('Magnetic flux density B along the x-axis');
legend;
grid on;

