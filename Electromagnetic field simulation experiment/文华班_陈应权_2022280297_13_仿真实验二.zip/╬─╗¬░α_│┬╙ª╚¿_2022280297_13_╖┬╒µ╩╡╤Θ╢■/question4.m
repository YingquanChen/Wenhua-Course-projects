% Constants
mu0 = 4 * pi * 1e-7;  % Permeability of free space (H/m)
I = 1;                % Current in Amperes
r_cylinder = 1e-3;    % Radius of the cylinder in meters
d = 0.001;            % Distance between a and b in meters

% Calculate area based on the provided geometry
area = pi * r_cylinder^2 - (0.5 * (2 * pi / 3) * r_cylinder^2);

% Current density
J = I / area;  % Current density (A/m^2)

% Magnetic field in the overlapping region
B = mu0 * J * d / 2;  % Magnetic field in Tesla

% Define x-axis range for the computation
x_range = linspace(-4e-4, 4e-4, 1000); % x values from -0.4 mm to 0.4 mm

% Create an array of magnetic field values (all equal to B)
B_array = B * ones(size(x_range));

% Load CST data from the file
data = readmatrix('E:\CST_result\2.4data.txt', 'FileType', 'text', 'NumHeaderLines', 2);

% Extract X positions and B-field values from CST data
x_cst = data(:, 1) * 1e-3; % Convert mm to m
B_cst = data(:, 2);

% Plot the calculated magnetic field B along the x-axis
figure;
plot(x_range * 1e3, B_array, 'bo-', 'DisplayName', 'Calculated B'); % Convert x_range to mm for plotting, using circle markers
hold on;

% Plot the CST magnetic field B along the x-axis
plot(x_cst * 1e3, B_cst, 'r^-', 'DisplayName', 'CST B'); % Convert x_cst to mm for plotting, using triangle markers

% Set plot details
xlabel('x (mm)');
ylabel('B (T)');
title('Magnetic Field B along the x-axis');
legend;
grid on;

% Adjust the y-axis limits
ylim([2e-4, 4e-4]);

