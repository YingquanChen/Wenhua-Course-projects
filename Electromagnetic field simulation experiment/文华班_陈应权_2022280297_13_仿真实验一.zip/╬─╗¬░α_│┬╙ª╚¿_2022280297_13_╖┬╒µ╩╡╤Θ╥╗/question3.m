% Constants
R_inner = 10e-3; % Inner radius of the conductor ball, unit: m
adj = 1.3 ;
R_outer = 20e-3 + adj*10*1e-3; % Outer radius of the dielectric shell, unit: m
Q = 1; % Charge on the conductor ball, unit: C
epsilon_r = 4; % Relative permittivity of the dielectric shell
epsilon_0 = 8.854e-12; % Vacuum permittivity, unit: F/m

% Distance range along the x-axis
x = linspace(0, 0.06, 2000); % Range along x-axis from -R_outer to R_outer

% Electric field calculation
E = zeros(size(x)); % Initialize electric field array
D = zeros(size(x)); % Initialize electric field array

for i = 1:length(x)
    if x(i) <= R_inner % Inside the conductor ball
        E(i) = 0; % Electric field inside a conductor is zero
        D(i)=0;
    elseif x(i) <= R_outer % Inside the dielectric shell
        E(i) = Q / (4 * pi * epsilon_0 * epsilon_r * x(i)^2); % Electric field due to a point charge in a dielectric
        D(i) = Q / (4 * pi* x(i)^2);
    else % Outside the dielectric shell
        E(i) = Q / (4 * pi * epsilon_0 * x(i)^2); % Electric field due to a point charge in vacuum
        D(i) = Q / (4 * pi* x(i)^2);
    end
end

% Electric displacement vector (D) calculation


figure;
a = importdata("E:\CST_result\1.3dataofE.txt");
data=a.data;
plot(x*1000, E, 'LineWidth', 2, 'DisplayName', 'calculated');
hold on;
plot(data(:, 1), data(:, 2), '--', 'LineWidth', 2, 'Marker', 'o', 'MarkerSize', 3,'DisplayName', 'imported');
hold on;
xlabel('x-axis coordinate (mm)');
ylabel('Electric field (N/C)');
title('Electric Field along the x-axis');
legend('Electric Field (E)');
grid on;


figure;
b = importdata("E:\CST_result\1.3dataofD.txt");
data=b.data;
plot(x*1000, D, 'LineWidth', 2, 'DisplayName', 'calculated');
hold on;
plot(data(:, 1), data(:, 2), '--', 'LineWidth', 2, 'Marker', 'o', 'MarkerSize', 3,'DisplayName', 'imported');
hold on;
xlabel('x-axis coordinate (mm)');
ylabel('Electric displacement (C/m^2)');
title('Electric Displacement along the x-axis');
legend('Electric Displacement (D)');
grid on;


