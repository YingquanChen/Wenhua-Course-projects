% 数据准备
original_parts1 = [0.10, 0.20, 0.10, 0.20, 0.10, 0.05];
original_parts2 = [0.10, 0.20, 0.10, 0.20, 0.20, 0.05];
original_products = [0.10, 0.20, 0.10, 0.20, 0.10, 0.05];

improved_parts1 = [0.0863, 0.1727, 0.0935, 0.2878, 0.0863, 0.0504];
improved_parts2 = [0.0647, 0.2158, 0.1223, 0.1871, 0.1727, 0.0216];
improved_products = [0.1367, 0.1942, 0.1367, 0.2230, 0.0576, 0.0791];

% 合并数据
data_parts1 = [original_parts1; improved_parts1]';
data_parts2 = [original_parts2; improved_parts2]';
data_products = [original_products; improved_products]';

% 绘制零件1次品率对比条形图
subplot(3,1,1);
bar(data_parts1);
title('零件1次品率对比');
xlabel('情况');
ylabel('次品率');
legend('原始值', '抽样结果');
xticklabels({'1', '2', '3', '4', '5', '6'});

% 绘制零件2次品率对比条形图
subplot(3,1,2);
bar(data_parts2);
title('零件2次品率对比');
xlabel('情况');
ylabel('次品率');
legend('原始值', '抽样结果');
xticklabels({'1', '2', '3', '4', '5', '6'});

% 绘制成品次品率对比条形图
subplot(3,1,3);
bar(data_products);
title('成品次品率对比');
xlabel('情况');
ylabel('次品率');
legend('原始值', '抽样结果');
xticklabels({'1', '2', '3', '4', '5', '6'});

% 原方法的最大收益
original_profit = [18.50, 14.00, 16.10, 12.80, 15.77, 19.70];

% 改进方法的最大收益
improved_profit = [17.50, 14.58, 15.06, 11.91, 19.24, 21.10];

% 情况标签
cases = {'情况1', '情况2', '情况3', '情况4', '情况5', '情况6'};

% 创建 x 轴位置
x = 1:6; % 原方法的 x 轴位置
x_offset = x + 0.25; % 改进方法的 x 轴位置

% 创建条形图
figure;

% 绘制原方法的条形图
bar(x - 0.125, original_profit, 0.25, 'FaceColor', [0.9, 0.7, 0.7]);
hold on;

% 绘制改进方法的条形图
bar(x + 0.125, improved_profit, 0.25,  'FaceColor', [0.7, 0.9, 0.7]);

% 设置图例
legend('原始值', '抽样结果', 'Location', 'northeast');

% 设置 x 轴刻度和标签
set(gca, 'XTick', x);
set(gca, 'XTickLabel', cases);

% 添加标题和标签
title('原始值与抽样结果最大收益对比');
xlabel('情况');
ylabel('最大收益');

% 显示网格
grid on;

% 关闭 hold
hold off;
