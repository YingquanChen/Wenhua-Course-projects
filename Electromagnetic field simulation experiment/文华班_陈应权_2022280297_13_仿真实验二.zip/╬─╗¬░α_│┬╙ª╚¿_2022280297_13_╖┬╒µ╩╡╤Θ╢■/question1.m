% Constants
mu0 = 4 * pi * 1e-7; % Permeability of free space (H/m)
I0 = 1; % Base current (A)
adj = 1.3; % Given adj value
I = I0 * (1 + adj); % Total current (A)

% Radii of the cylinder
r_inner = 1e-3; % Inner radius (m)
r_outer = 1.5e-3; % Outer radius (m)

% Define x positions where B is to be calculated
x_positions = linspace(-40e-3, 40e-3, 100); % X positions from -40mm to 40mm

% Initialize B array
B = zeros(size(x_positions));

% Calculate B at each x position
for i = 1:length(x_positions)
    x = x_positions(i);
    if abs(x) <= r_inner
        % Inside the inner radius, B is 0
        B(i) = 0;
    elseif abs(x) > r_inner && abs(x) <= r_outer
        % Between inner and outer radius
        B(i) = (mu0 * I / (2 * pi * abs(x))) * (abs(x)^2 - r_inner^2) / (r_outer^2 - r_inner^2);
    else
        % Outside the outer radius
        B(i) = (mu0 * I / (2 * pi * abs(x))) * (r_outer^2 - r_inner^2) / (r_outer^2 - r_inner^2);
    end
end

% Load CST data from the file
data = readmatrix("E:\CST_result\data2.1.txt", 'FileType', 'text', 'NumHeaderLines', 2);

% Extract X positions and B-field values from CST data
x_cst = data(:, 1) * 1e-3; % Convert mm to m
B_cst = data(:, 2);

% Plot both the calculated and CST data
figure;
plot(x_positions * 1e3, B, 'bo-', 'DisplayName', 'Calculated B'); % Convert x_positions to mm for plotting, using circle markers
hold on;
plot(x_cst * 1e3, B_cst, 'r^-', 'DisplayName', 'CST B'); % Convert x_cst to mm for plotting, using triangle markers
xlabel('x (mm)');
ylabel('Magnetic field B (T)');
title('Magnetic field B along the x-axis');
legend;
grid on;

