close all;clc;clear;

% 定义参数（次品率，购买单价，检测成本，装配成本，市场售价，调换损失，拆解费用）
data = [
    0.10, 4, 2, 0.10, 18, 3, 0.10, 6, 3, 56, 6, 5;
    0.20, 4, 2, 0.20, 18, 3, 0.20, 6, 3, 56, 6, 5;
    0.10, 4, 2, 0.10, 18, 3, 0.10, 6, 3, 56, 30, 5;
    0.20, 4, 1, 0.20, 18, 1, 0.20, 6, 2, 56, 30, 5;
    0.10, 4, 8, 0.20, 18, 1, 0.10, 6, 2, 56, 10, 5;
    0.05, 4, 2, 0.05, 18, 3, 0.05, 6, 3, 56, 10, 40;
];

% 结果保存变量
profits = zeros(size(data, 1), 16); % 保存16种策略的收益
decisions = strings(size(data,1), 4); % 用于记录每一步的检测和拆解决策

% 遍历所有情况
for i = 1:size(data,1)
    strategy_index = 1; % 用于记录16种策略的索引
    for detect_part1 = [true, false]
        for detect_part2 = [true, false]
            for detect_final = [true, false]
                for disassemble = [true, false]
                    % 计算当前决策组合的总成本和收益
                    [~, current_profit] = evaluate_cost_and_profit(detect_part1, detect_part2, detect_final, disassemble, i, data);
                    
                    % 保存当前策略的收益
                    profits(i, strategy_index) = current_profit;
                    strategy_index = strategy_index + 1;
                end
            end
        end
    end
end

% 绘制直方图
for i = 1:size(data, 1)
    figure;
    bar(profits(i, :)); % 绘制每种情况下的16种策略的收益
    title(sprintf('情况 %d 的16种策略收益', i));
    xlabel('策略编号');
    ylabel('收益');
end

% 定义递归函数，动态评估每一步的成本和收益
function [total_cost, total_profit] = evaluate_cost_and_profit(part1_detected, part2_detected, final_detected, disassemble, i, data)
    % 读取数据
    defect_part1 = data(i,1);  % 零配件1次品率
    price_part1 = data(i,2);   % 零配件1购买单价
    detect_cost_part1 = data(i,3);  % 零配件1检测成本
    
    defect_part2 = data(i,4);  % 零配件2次品率
    price_part2 = data(i,5);   % 零配件2购买单价
    detect_cost_part2 = data(i,6);  % 零配件2检测成本
    
    defect_final = data(i,7);  % 成品次品率
    assembly_cost = data(i,8); % 成品装配成本
    detect_cost_final = data(i,9); % 成品检测成本
    
    market_price = data(i,10); % 市场售价
    replacement_cost = data(i,11); % 调换损失
    disassemble_cost = data(i,12); % 拆解费用
    
    % 计算不同决策的成本
    
    % 1. 零件1检测与否的成本
    if part1_detected
        part1_cost = detect_cost_part1 + price_part1; % 检测并丢弃不合格品
        defect_part1_prob = 0; % 检测后次品率为0
    else
        part1_cost = price_part1; % 未检测则直接使用
        defect_part1_prob = defect_part1;
    end
    
    % 2. 零件2检测与否的成本
    if part2_detected
        part2_cost = detect_cost_part2 + price_part2; % 检测并丢弃不合格品
        defect_part2_prob = 0; % 检测后次品率为0
    else
        part2_cost = price_part2; % 未检测则直接使用
        defect_part2_prob = defect_part2;
    end
    
    % 3. 成品检测与否的成本
    combined_defect_prob = 1 - (1 - defect_part1_prob) * (1 - defect_part2_prob) * (1 - defect_final); % 成品不合格概率
    if final_detected
        final_cost = detect_cost_final + assembly_cost; % 检测成品
        final_defect_prob = 0; % 检测后的成品次品率为0
    else
        final_cost = assembly_cost; % 不检测成品
        final_defect_prob = combined_defect_prob;
    end
    
    % 4. 退换与拆解的成本
    if disassemble
        % 计算条件概率：基于成品不合格的前提，分别计算零件1和零件2不合格的概率
        if ~part1_detected && ~part2_detected
            % 情况：1和2都没有检测
            P_defect_part1_given_final = defect_part1 / (1 - (1 - defect_part1) * (1 - defect_part2) * (1 - defect_final));
            P_defect_part2_given_final = defect_part2 / (1 - (1 - defect_part1) * (1 - defect_part2) * (1 - defect_final));
        elseif part1_detected && ~part2_detected
            % 情况：1检测过，2没有检测
            P_defect_part1_given_final = 0; % 零件1已经检测合格
            P_defect_part2_given_final = defect_part2 / (1 - (1 - defect_part2) * (1 - defect_final));
        elseif ~part1_detected && part2_detected
            % 情况：1没有检测，2检测过
            P_defect_part1_given_final = defect_part1 / (1 - (1 - defect_part1) * (1 - defect_final));
            P_defect_part2_given_final = 0; % 零件2已经检测合格
        else
            % 情况：1和2都检测过
            P_defect_part1_given_final = 0;
            P_defect_part2_given_final = 0;
        end
    
        % 根据条件概率计算合格零件的回收收益
        part1_recovery = (1 - P_defect_part1_given_final) * price_part1;
        part2_recovery = (1 - P_defect_part2_given_final) * price_part2;
        disassemble_benefit = part1_recovery + part2_recovery;
    
        % 检测成本只在未检测时计算
        part1_detect_cost = 0;
        part2_detect_cost = 0;
    
        if ~part1_detected
            part1_detect_cost = detect_cost_part1;
        end
    
        if ~part2_detected
            part2_detect_cost = detect_cost_part2;
        end
    
        % 计算修理成本，扣除合格零件回收收益
        repair_cost = final_defect_prob * (replacement_cost + disassemble_cost + part1_detect_cost + part2_detect_cost - disassemble_benefit);
    else
        % 不拆解，直接报废，修理成本为调换损失
        repair_cost = final_defect_prob * replacement_cost;
    end

    
    % 总成本
    total_cost = part1_cost + part2_cost + final_cost + repair_cost;
    
    % 计算收益
    successful_final_prob = (1 - defect_part1_prob) * (1 - defect_part2_prob) * (1 - defect_final);
    total_profit = successful_final_prob * market_price - total_cost; % 成品销售收益 - 成本
end

% 布尔值转字符串函数
function str = bool_to_str(val)
    if val
        str = '检测';
    else
        str = '不检测';
    end
end

function str = whether_disassemble(val)
    if val
        str = '拆解';
    else
        str = '不拆解';
    end
end
