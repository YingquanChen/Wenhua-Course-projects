% Parameter settings
R = 0.01; % Sphere radius (m)
Q = 1;    % Total charge uniformly distributed on the sphere (Coulombs)
adj = 1.3;

% Permittivity of vacuum
epsilon_0 = 8.85e-12; % (Coulombs per newton·square meter)

% Compute the range of points on the x-axis
x_range = linspace(0, 0.04, 100); % Assume x varies between radius 0 to 2R

% Initialize the array for electric field strength
E_x = zeros(size(x_range));

% Compute electric field strength at each point on the x-axis
for i = 1:length(x_range)
    x = x_range(i);
    
    if x <= R
        % Electric field inside the sphere: linear change
        E_x(i) = Q / (4 * pi * epsilon_0 * (1 + adj) * R^3) * x;
    else
        % Electric field outside the sphere: follows 1/r^2 change
        r = sqrt(x^2); % Distance from point (x, 0, 0) to the center of the sphere
        E_x(i) = Q / (4 * pi * epsilon_0 * r^2);
    end
end

% Load data from file
a = importdata("E:\CST_result\1.1data.txt");
data = a.data;

% Plot both calculated and imported electric field data
plot(x_range*1000, E_x, 'LineWidth', 2, 'DisplayName', 'calculated');
hold on;
plot(data(:, 1), data(:, 2), '--', 'LineWidth', 2, 'Marker', 'o', 'MarkerSize', 3,'DisplayName', 'imported');
hold off;

% Set labels and title
xlabel('x (mm)');
ylabel('Electric Field (N/C)');
title('Comparison of Electric Field');
legend('show');
grid on;
