% Constants
mu0 = 4 * pi * 1e-7; % Permeability of free space (H/m)
adj=1.3;

I = 1; % Total current (A)

% Radius of the circular wire
R = (20 + adj) * 1e-3; % Radius in meters

% Calculate the magnetic field at the center
B = mu0 * I / (2 * R);

% Display the result
fprintf('The magnetic field at the center of the circular wire is %.2e T\n', B);
