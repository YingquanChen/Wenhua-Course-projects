% Constants
R_inner = 10e-3; % Inner radius of the inner conductor, unit: m
R_outer_inner = 20e-3; % Inner radius of the outer conductor, unit: m
R_outer_outer = 30e-3; % Outer radius of the outer conductor, unit: m
Q_inner = 1; % Charge on the inner conductor, unit: C
Q_outer = -1; % Charge on the outer conductor, unit: C
adj = 1.3;
epsilon_r1 = 2 + adj; % Relative permittivity of the upper half, unitless
epsilon_r2 = 4; % Relative permittivity of the lower half, unitless
epsilon_0 = 8.854e-12; % Vacuum permittivity, unit: F/m

% Distance range along the y-axis (0-30mm)
x = linspace(-30e-3, 30e-3, 1000); % Range along y-axis

% Electric field calculation
E = zeros(size(x)); % Initialize electric field array
D = zeros(size(x)); % Initialize electric displacement array

for i = 1:length(x)
    if abs(x(i)) <= R_inner % Inside the inner conductor
        E(i) = 0; % Electric field inside a conductor is zero
        D(i) = 0; % Electric displacement inside a conductor is zero
    elseif abs(x(i)) <= R_outer_inner % Between inner and outer conductor
        if x(i) >= 0 % Upper half
            epsilon = epsilon_r1;
        else % Lower half
            epsilon = epsilon_r2;
        end
        E(i) = Q_inner / (2 * pi * epsilon_0 * (epsilon_r1 +epsilon_r2) * x(i)^2); 
        D(i) = epsilon_0 * epsilon * E(i);
    else % Beyond the outer conductor
        E(i) = 0; % Electric field outside the outer conductor is zero
        D(i) = 0; % Electric displacement outside the outer conductor is zero
    end
end

% Plotting E(y) and D(y)
figure;
a = importdata("E:\CST_result\1.4dataE.txt");
data=a.data;
plot(x*1000, E, 'LineWidth', 2, 'DisplayName', 'calculated');
hold on;
plot(data(:, 1), data(:, 2), '--', 'LineWidth', 2, 'Marker', 'o', 'MarkerSize', 3,'DisplayName', 'imported');
hold off;
title('Electric Field (E) along y-axis');
xlabel('x (mm)');
ylabel('Electric Field (N/C)');
grid on;

figure;
b = importdata("E:\CST_result\1.4dataD.txt");
data=b.data;
plot(x*1000, D, 'LineWidth', 2, 'DisplayName', 'calculated');
hold on;
plot(data(:, 1), data(:, 2), '--', 'LineWidth', 2, 'Marker', 'o', 'MarkerSize', 3,'DisplayName', 'imported');
hold off;
title('Electric Displacement (D) along y-axis');
xlabel('x(mm)');
ylabel('Electric Displacement (C/m^2)');
grid on;
