% Define constants
epsilon = 8.854 * 10^(-12); % Permittivity of vacuum (C/V·m)
r1 = 0.02; % Radius of the first sphere, 20mm
r2 = 0.008; % Radius of the second sphere, 8mm
c = 0.01;


% Calculate volume difference
V = (4/3) * pi * (r1^3 - r2^3);

% Total charge is 1C
Q = 1; % Charge (C)

% Calculate volume charge density
rho = Q / V;

x = linspace(0.002, 0.018, 10000); % Create 10000 points from 2mm to 18mm

% Theoretical calculation of the electric field formula inside the cavity
E = (rho * c) / (3 * epsilon) * ones(size(x));


a = importdata("E:\CST_result\1.5data.txt");
data=a.data;
plot(x*1000, E, 'LineWidth', 2, 'DisplayName', 'calculated');
hold on;
plot(data(:, 1), data(:, 2), '--', 'LineWidth', 2, 'Marker', 'o', 'MarkerSize', 3,'DisplayName', 'imported');
hold off;
xlabel('Distance from the sphere center (mm)');
ylabel('Electric Field Strength (N/C)');
title('Electric Field Distribution along the x-axis');
